/* DimSI 1.0 Poisson Model */
/* copyright 2012 Paul Hohenlohe */
/* permission is granted to use and modify this software _provided that_ any
* publication resulting from use of this software or any part or modification thereof
* contains at least one of the following citations:
*
* Hohenlohe, P.A.  2010.  DimSI: Dimensionality of Sexual Isolation.
* Software available at http://webpages.uidaho.edu/hohenlohe/software
*
* Hohenlohe, P.A. & S.J. Arnold.  2010.  The dimensionality of mate choice, sexual isolation
* and speciation.  Proc Nat Acad Sci USA 107:16583-16588.
*
* questions/comments: hohenlohe@uidaho.edu */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <time.h>
#include "DimSI_Funx.h"

int spp, opt, cycles, summary, max_d;  /* opt is for verbose output (spits out matrices) */
char **spnames;
int **datacounts; /* [spp (female)][spp (male)] number of mating events */
double lnLconstant;

void free_all();
void read_files(char *datafile);
void check_read();
void output(char *outfile);
double maximize_L(double **points, int dim, double *p, int iter);
void memerror();

int main(int argc, char *argv[]) {
	int i;
	char *datafilename, *outfilename;
	srand48((unsigned) time(NULL));
	datafilename = "datafile.txt";
	outfilename = "outfile.txt";
	opt = 0; cycles = 20; max_d = 0; summary = 0;
	if(argc < 2 || strcmp(argv[1], "-h") == 0) 
		{printf("usage is ./Poisson datafile.txt [-o outfile.txt] [-v] [-c 20] [-summary] [-max spp]\n\n"); exit(0); }
	for(i=1; i<argc; i++) {
		if(strcmp(argv[i], "-o") == 0) {
			if(i < (argc - 1)) {i++; outfilename = argv[i]; }
		}
		else if(strcmp(argv[i], "-c") == 0) {
			if(i < (argc - 1)) {i++; cycles = atoi(argv[i]); }
		}
		else if(strcmp(argv[i], "-max") == 0) {
			if(i < (argc - 1)) {i++; max_d = atoi(argv[i]); }
		}
		else if(strcmp(argv[i], "-v") == 0) opt = 1;
		else if(strcmp(argv[i], "-summary") == 0) summary = 1;
		else datafilename = argv[i];
	}
	read_files(datafilename);
	output(outfilename);
	if(opt) check_read();
	free_all();
	return 0;
}

void free_all() {
	int i;
	for(i=0; i<spp; i++) {free(spnames[i]); free(datacounts[i]); }
	free(spnames); free(datacounts); 
}

void read_files(char *datafile) {
	int i, j, k, l, tmpint, **tmpdata, comp;
	char **tmp, *tmpsp1, *tmpsp2;
	FILE *f;
	if((tmpsp1 = malloc(50*sizeof(char))) == NULL) memerror();
	if((tmpsp2 = malloc(50*sizeof(char))) == NULL) memerror();
	f = fopen(datafile, "r");
	fscanf(f, "%d", &spp);
	fscanf(f, "%d", &comp);
	if((tmp = realloc(spnames, spp*sizeof(char *))) == NULL) memerror();
	for(i=0; i<spp; i++) if((tmp[i] = malloc(50*sizeof(char))) == NULL) memerror();
	spnames = tmp;
	if((tmpdata = realloc(datacounts, spp*sizeof(int *))) == NULL) memerror();
	for(i=0; i<spp; i++) if((tmpdata[i] = malloc(spp*sizeof(int))) == NULL) memerror();
	datacounts = tmpdata;
	for(i=0; i<spp; i++) for(j=0; j<spp; j++) datacounts[i][j] = 0;
	for(i=0; i<spp; i++) fscanf(f, "%s", spnames[i]);
	for(i=0; i<comp; i++) {
		fscanf(f, "%s", tmpsp1);
		fscanf(f, "%s", tmpsp2);
		k = 0; l = 0;
		while(k < spp && strcmp(tmpsp1,spnames[k]) != 0) k++;
		if(k == spp) {printf("Can't find species %s\n\n\n",tmpsp1); exit(0); }
		while(l < spp && strcmp(tmpsp2,spnames[l]) != 0) l++;
		if(l == spp) {printf("Can't find species %s\n\n\n",tmpsp2); exit(0); }
		fscanf(f, "%d", &tmpint); datacounts[k][l] += tmpint;
	}
	fclose(f);
	lnLconstant = Poisson_constant(datacounts, spp);
}

void check_read() {
	int i, j;
	printf("\n%d species\n\nMatrix of mating events:\n", spp);
	printf("f\\m");
	for(i=0; i<spp; i++) printf("\t%s", spnames[i]);
	printf("\n");
	for(i=0; i<spp; i++) {
		printf("%s", spnames[i]);
		for(j=0; j<spp; j++) {
			printf("\t%d", datacounts[i][j]);
		}
		printf("\n");
	}
	printf("\n\n");
}

void output(char *outfile) {
	/* free parameters in points are 2*d*spp - d(d + 1)/2 */
	int i, j, k, l, m, D, total_n, jump, *perm;
	double **points, **tmppoints, *p, like0, like1, AIC, nD;
	FILE *f;
	f = fopen(outfile, "w");
	fprintf(f,"Dim\tlnL\tConst\tlnL\tAIC\tparams\tp\n");
	if(max_d == 0) max_d = spp; 
	else max_d = minimum(max_d, 2*spp);
	total_n = 0;
	for(i=0; i<spp; i++) for(j=0; j<spp; j++) total_n += datacounts[i][j];
	if((points = malloc(2*spp*sizeof(double *))) == NULL) memerror();
	for(i=0; i<(2*spp); i++) if((points[i] = malloc(max_d*sizeof(double))) == NULL) memerror();
	if((tmppoints = malloc(2*spp*sizeof(double *))) == NULL) memerror();
	for(i=0; i<(2*spp); i++) if((tmppoints[i] = malloc(max_d*sizeof(double))) == NULL) memerror();
	if((perm = malloc(2*spp*sizeof(int))) == NULL) memerror();
	if((p = malloc(sizeof(double))) == NULL) memerror();
	if(max_d == 0) max_d = spp; 
	else max_d = minimum(max_d, 2*spp);
	D = 1;
	like0 = -99999999999999.0;
	for(i=0; i<2*spp; i++) for(j=0; j<max_d; j++) points[i][j] = 0;
	for(i=0; i<spp*spp*cycles; i++) {
		k = random_permutation(perm, 2*spp);
		for(j=0; j<(2*spp); j++) tmppoints[j][0] = 0.25*((double) perm[j]);
		like1 = maximize_L(tmppoints, D, p, cycles);
		if(like1 > like0) {for(k=0; k<(2*spp); k++) points[k][0] = tmppoints[k][0]; like0 = like1; }
	}
	for(D=1; D<max_d; D++) {
		for(i=0; i<2*spp; i++) for(j=0; j<D; j++) tmppoints[i][j] = points[i][j];
		if(D > 1) {
			k = Poisson_max_cost(datacounts, points, spp, D, p[0]);
			points[k][D - 1] = 0.5;
		}
		like0 = maximize_L(points, D, p, cycles);
		for(i=0; i<cycles; i++) {
			jump = 1;
			for(j=0; j<spp; j++) {
				for(k=0; k<spp; k++) {
					if(k == j) continue;
					for(l=0; l<2*spp; l++) for(m=0; m<D; m++) tmppoints[l][k] = points[l][m];
					for(m=0; m<D; m++) {tmppoints[j][m] = points[k][m]; tmppoints[spp + j][m] = points[spp + k][m];
						tmppoints[k][m] = points[j][m]; tmppoints[spp + k][m] = points[spp + j][m];}
					like1 = maximize_L(tmppoints, D, p, cycles);
					if(opt) printf("%d p\t%4.4lf\t%4.4lf\n",D,like0, like1);
					if(like1 > like0) 
						{for(l=0; l<2*spp; l++) for(m=0; m<D; m++) points[l][m] = tmppoints[l][m]; like0 = like1; if(opt) printf("swap\n"); jump = 0; }
				}
			}
			if(jump == 1) break;
		}
		for(i=0; i<cycles; i++) {
			jump = 1;
			for(j=0; j<2*spp; j++) {
				for(k=0; k<2*spp; k++) {
					if(k == j) continue;
					for(l=0; l<2*spp; l++) for(m=0; m<D; m++) tmppoints[l][k] = points[l][m];
					for(m=0; m<D; m++) {tmppoints[j][m] = points[k][m]; tmppoints[k][m] = points[j][m]; }
					like1 = maximize_L(tmppoints, D, p, cycles);
					if(opt) printf("%d\t%4.4lf\t%4.4lf\n",D,like0, like1);
					if(like1 > like0) 
						{for(l=0; l<2*spp; l++) for(m=0; m<D; m++) points[l][m] = tmppoints[l][m]; like0 = like1; if(opt) printf("swap\n"); jump = 0; }
				}
			}
			if(jump == 1) break;
		}
		like0 = maximize_L(points, D, p, cycles);
		if(opt) printf("final %d\t%4.4lf\n",D,like0);
		nD = CenterandRotate(points, tmppoints, 2*spp, D);
		for(i=0; i<2*spp; i++) for(j=0; j<D; j++) points[i][j] = tmppoints[i][j];
		k = 2*D*spp - D*(D + 1)/2 + 1;
		AIC = 2*k - 2*(like0 - lnLconstant) + 2*k*(k+1)/(total_n - k -1);
		fprintf(f,"%d\t%4.8lf\t%4.8lf\t%d\t%4.4lf\t%4.4lf\n", D, like0 - lnLconstant, AIC, k, p[0], nD);
		if(summary == 0) {
			for(i=0; i<spp; i++) {
				fprintf(f,"%s F\t",spnames[i]); for(k=0; k<D; k++) fprintf(f,"%4.4lf\t", points[i][k]); 
				fprintf(f,"\n%s M\t",spnames[i]); for(k=0; k<D; k++) fprintf(f,"%4.4lf\t",points[spp + i][k]); fprintf(f,"\n");
			}
		}
	}
	fclose(f);
	for(j=0; j<2*spp; j++) free(points[j]); free(points);
	for(j=0; j<2*spp; j++) free(tmppoints[j]); free(tmppoints);
	free(perm);
}

double maximize_L(double **points, int dim, double *p, int iter) {
	int i,j,k,m;  /* maximizes total lnL from points by iterating through females & males, trying Newton method then gradient method */
	double out, dx, likehere, likethere, gamma, **tmppoints;
	if((tmppoints = malloc(2*spp*sizeof(double *))) == NULL) memerror();
	for(i=0; i<(2*spp); i++) if((tmppoints[i] = malloc(dim*sizeof(double))) == NULL) memerror();
	dx = 0.001;
	gamma = 0.01;
	k = 0;
	for(m=0; m<(iter*spp); m++) {
		likehere = PoissonlnL_point(datacounts, points, k, spp, dim, p[0]);
		likethere = Poisson_point_Newton_approx(datacounts, points, k, spp, dim, p[0], dx, tmppoints);
		if(likethere >= likehere) 
			{likehere = likethere; for(j=0; j<dim; j++) points[k][j] = tmppoints[k][j]; p[0] = Poisson_max_p(datacounts, points, spp, dim); }
		else {
			likethere = Poisson_point_gradient_approx(datacounts, points, k, spp, dim, p[0], dx, gamma, tmppoints);
			if(likethere >= likehere) 
				{likehere = likethere; for(j=0; j<dim; j++) points[k][j] = tmppoints[k][j]; p[0] = Poisson_max_p(datacounts, points, spp, dim); }
		}
		k++; if(k >= 2*spp) k = 0;
	}
	out = PoissonlnL_total(datacounts, points, spp, dim, p[0]);
	for(j=0; j<spp; j++) free(tmppoints[j]); free(tmppoints);
	return out;
}










